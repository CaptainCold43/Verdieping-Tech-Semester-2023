﻿namespace Bankrekening_opdracht_7._1._3
{
    partial class BankAccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbAccountLinks = new System.Windows.Forms.GroupBox();
            this.btOpnemenLinks = new System.Windows.Forms.Button();
            this.btStortenLinks = new System.Windows.Forms.Button();
            this.lblSaldoValueLinks = new System.Windows.Forms.Label();
            this.lblSaldoLinks = new System.Windows.Forms.Label();
            this.btOvermakenLinks = new System.Windows.Forms.Button();
            this.gbAccountRechts = new System.Windows.Forms.GroupBox();
            this.btOpnemenRechts = new System.Windows.Forms.Button();
            this.btStortenRechts = new System.Windows.Forms.Button();
            this.lblSaldoValueRechts = new System.Windows.Forms.Label();
            this.lblSaldoRechts = new System.Windows.Forms.Label();
            this.btOvermakenRechts = new System.Windows.Forms.Button();
            this.lblInvoerLinks = new System.Windows.Forms.Label();
            this.tbInvoerLinksEuros = new System.Windows.Forms.TextBox();
            this.tbInvoerRechtsEuros = new System.Windows.Forms.TextBox();
            this.lblInvoerRechts = new System.Windows.Forms.Label();
            this.tbInvoerLinksCenten = new System.Windows.Forms.TextBox();
            this.tbInvoerRechtsCenten = new System.Windows.Forms.TextBox();
            this.lblPuntLinks = new System.Windows.Forms.Label();
            this.lblPuntRechts = new System.Windows.Forms.Label();
            this.gbAccountLinks.SuspendLayout();
            this.gbAccountRechts.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbAccountLinks
            // 
            this.gbAccountLinks.Controls.Add(this.btOpnemenLinks);
            this.gbAccountLinks.Controls.Add(this.btStortenLinks);
            this.gbAccountLinks.Controls.Add(this.lblSaldoValueLinks);
            this.gbAccountLinks.Controls.Add(this.lblSaldoLinks);
            this.gbAccountLinks.Location = new System.Drawing.Point(13, 13);
            this.gbAccountLinks.Name = "gbAccountLinks";
            this.gbAccountLinks.Size = new System.Drawing.Size(174, 132);
            this.gbAccountLinks.TabIndex = 0;
            this.gbAccountLinks.TabStop = false;
            this.gbAccountLinks.Text = "Account";
            // 
            // btOpnemenLinks
            // 
            this.btOpnemenLinks.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btOpnemenLinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btOpnemenLinks.Location = new System.Drawing.Point(6, 81);
            this.btOpnemenLinks.Name = "btOpnemenLinks";
            this.btOpnemenLinks.Size = new System.Drawing.Size(114, 34);
            this.btOpnemenLinks.TabIndex = 3;
            this.btOpnemenLinks.Text = "Opnemen";
            this.btOpnemenLinks.UseVisualStyleBackColor = false;
            this.btOpnemenLinks.Click += new System.EventHandler(this.btOpnemenLinks_Click);
            // 
            // btStortenLinks
            // 
            this.btStortenLinks.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btStortenLinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btStortenLinks.Location = new System.Drawing.Point(6, 41);
            this.btStortenLinks.Name = "btStortenLinks";
            this.btStortenLinks.Size = new System.Drawing.Size(114, 34);
            this.btStortenLinks.TabIndex = 2;
            this.btStortenLinks.Text = "Storten";
            this.btStortenLinks.UseVisualStyleBackColor = false;
            this.btStortenLinks.Click += new System.EventHandler(this.btStortenLinks_Click);
            // 
            // lblSaldoValueLinks
            // 
            this.lblSaldoValueLinks.AutoSize = true;
            this.lblSaldoValueLinks.Location = new System.Drawing.Point(63, 21);
            this.lblSaldoValueLinks.Name = "lblSaldoValueLinks";
            this.lblSaldoValueLinks.Size = new System.Drawing.Size(14, 16);
            this.lblSaldoValueLinks.TabIndex = 1;
            this.lblSaldoValueLinks.Text = "0";
            // 
            // lblSaldoLinks
            // 
            this.lblSaldoLinks.AutoSize = true;
            this.lblSaldoLinks.Location = new System.Drawing.Point(7, 22);
            this.lblSaldoLinks.Name = "lblSaldoLinks";
            this.lblSaldoLinks.Size = new System.Drawing.Size(49, 16);
            this.lblSaldoLinks.TabIndex = 0;
            this.lblSaldoLinks.Text = "Saldo: ";
            // 
            // btOvermakenLinks
            // 
            this.btOvermakenLinks.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btOvermakenLinks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btOvermakenLinks.Location = new System.Drawing.Point(213, 54);
            this.btOvermakenLinks.Name = "btOvermakenLinks";
            this.btOvermakenLinks.Size = new System.Drawing.Size(114, 34);
            this.btOvermakenLinks.TabIndex = 4;
            this.btOvermakenLinks.Text = ">>";
            this.btOvermakenLinks.UseVisualStyleBackColor = false;
            this.btOvermakenLinks.Click += new System.EventHandler(this.btOvermakenLinks_Click);
            // 
            // gbAccountRechts
            // 
            this.gbAccountRechts.Controls.Add(this.btOpnemenRechts);
            this.gbAccountRechts.Controls.Add(this.btStortenRechts);
            this.gbAccountRechts.Controls.Add(this.lblSaldoValueRechts);
            this.gbAccountRechts.Controls.Add(this.lblSaldoRechts);
            this.gbAccountRechts.Location = new System.Drawing.Point(345, 13);
            this.gbAccountRechts.Name = "gbAccountRechts";
            this.gbAccountRechts.Size = new System.Drawing.Size(170, 132);
            this.gbAccountRechts.TabIndex = 1;
            this.gbAccountRechts.TabStop = false;
            this.gbAccountRechts.Text = "Account";
            // 
            // btOpnemenRechts
            // 
            this.btOpnemenRechts.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btOpnemenRechts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btOpnemenRechts.Location = new System.Drawing.Point(6, 81);
            this.btOpnemenRechts.Name = "btOpnemenRechts";
            this.btOpnemenRechts.Size = new System.Drawing.Size(114, 34);
            this.btOpnemenRechts.TabIndex = 3;
            this.btOpnemenRechts.Text = "Opnemen";
            this.btOpnemenRechts.UseVisualStyleBackColor = false;
            this.btOpnemenRechts.Click += new System.EventHandler(this.btOpnemenRechts_Click);
            // 
            // btStortenRechts
            // 
            this.btStortenRechts.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btStortenRechts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btStortenRechts.Location = new System.Drawing.Point(6, 41);
            this.btStortenRechts.Name = "btStortenRechts";
            this.btStortenRechts.Size = new System.Drawing.Size(114, 34);
            this.btStortenRechts.TabIndex = 2;
            this.btStortenRechts.Text = "Storten";
            this.btStortenRechts.UseVisualStyleBackColor = false;
            this.btStortenRechts.Click += new System.EventHandler(this.btStortenRechts_Click);
            // 
            // lblSaldoValueRechts
            // 
            this.lblSaldoValueRechts.AutoSize = true;
            this.lblSaldoValueRechts.Location = new System.Drawing.Point(63, 21);
            this.lblSaldoValueRechts.Name = "lblSaldoValueRechts";
            this.lblSaldoValueRechts.Size = new System.Drawing.Size(14, 16);
            this.lblSaldoValueRechts.TabIndex = 1;
            this.lblSaldoValueRechts.Text = "0";
            // 
            // lblSaldoRechts
            // 
            this.lblSaldoRechts.AutoSize = true;
            this.lblSaldoRechts.Location = new System.Drawing.Point(7, 22);
            this.lblSaldoRechts.Name = "lblSaldoRechts";
            this.lblSaldoRechts.Size = new System.Drawing.Size(49, 16);
            this.lblSaldoRechts.TabIndex = 0;
            this.lblSaldoRechts.Text = "Saldo: ";
            // 
            // btOvermakenRechts
            // 
            this.btOvermakenRechts.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btOvermakenRechts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btOvermakenRechts.Location = new System.Drawing.Point(213, 94);
            this.btOvermakenRechts.Name = "btOvermakenRechts";
            this.btOvermakenRechts.Size = new System.Drawing.Size(114, 34);
            this.btOvermakenRechts.TabIndex = 4;
            this.btOvermakenRechts.Text = "<<";
            this.btOvermakenRechts.UseVisualStyleBackColor = false;
            this.btOvermakenRechts.Click += new System.EventHandler(this.btOvermakenRechts_Click);
            // 
            // lblInvoerLinks
            // 
            this.lblInvoerLinks.AutoSize = true;
            this.lblInvoerLinks.Location = new System.Drawing.Point(12, 156);
            this.lblInvoerLinks.Name = "lblInvoerLinks";
            this.lblInvoerLinks.Size = new System.Drawing.Size(47, 16);
            this.lblInvoerLinks.TabIndex = 2;
            this.lblInvoerLinks.Text = "Invoer:";
            // 
            // tbInvoerLinksEuros
            // 
            this.tbInvoerLinksEuros.Location = new System.Drawing.Point(62, 156);
            this.tbInvoerLinksEuros.Name = "tbInvoerLinksEuros";
            this.tbInvoerLinksEuros.Size = new System.Drawing.Size(71, 22);
            this.tbInvoerLinksEuros.TabIndex = 3;
            // 
            // tbInvoerRechtsEuros
            // 
            this.tbInvoerRechtsEuros.Location = new System.Drawing.Point(404, 156);
            this.tbInvoerRechtsEuros.Name = "tbInvoerRechtsEuros";
            this.tbInvoerRechtsEuros.Size = new System.Drawing.Size(66, 22);
            this.tbInvoerRechtsEuros.TabIndex = 5;
            // 
            // lblInvoerRechts
            // 
            this.lblInvoerRechts.AutoSize = true;
            this.lblInvoerRechts.Location = new System.Drawing.Point(354, 156);
            this.lblInvoerRechts.Name = "lblInvoerRechts";
            this.lblInvoerRechts.Size = new System.Drawing.Size(47, 16);
            this.lblInvoerRechts.TabIndex = 4;
            this.lblInvoerRechts.Text = "Invoer:";
            // 
            // tbInvoerLinksCenten
            // 
            this.tbInvoerLinksCenten.Location = new System.Drawing.Point(148, 156);
            this.tbInvoerLinksCenten.Name = "tbInvoerLinksCenten";
            this.tbInvoerLinksCenten.Size = new System.Drawing.Size(39, 22);
            this.tbInvoerLinksCenten.TabIndex = 6;
            // 
            // tbInvoerRechtsCenten
            // 
            this.tbInvoerRechtsCenten.Location = new System.Drawing.Point(481, 156);
            this.tbInvoerRechtsCenten.Name = "tbInvoerRechtsCenten";
            this.tbInvoerRechtsCenten.Size = new System.Drawing.Size(34, 22);
            this.tbInvoerRechtsCenten.TabIndex = 7;
            // 
            // lblPuntLinks
            // 
            this.lblPuntLinks.AutoSize = true;
            this.lblPuntLinks.Location = new System.Drawing.Point(136, 159);
            this.lblPuntLinks.Name = "lblPuntLinks";
            this.lblPuntLinks.Size = new System.Drawing.Size(10, 16);
            this.lblPuntLinks.TabIndex = 8;
            this.lblPuntLinks.Text = ".";
            // 
            // lblPuntRechts
            // 
            this.lblPuntRechts.AutoSize = true;
            this.lblPuntRechts.Location = new System.Drawing.Point(471, 160);
            this.lblPuntRechts.Name = "lblPuntRechts";
            this.lblPuntRechts.Size = new System.Drawing.Size(10, 16);
            this.lblPuntRechts.TabIndex = 9;
            this.lblPuntRechts.Text = ".";
            // 
            // BankAccountForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 204);
            this.Controls.Add(this.lblPuntRechts);
            this.Controls.Add(this.lblPuntLinks);
            this.Controls.Add(this.tbInvoerRechtsCenten);
            this.Controls.Add(this.tbInvoerLinksCenten);
            this.Controls.Add(this.btOvermakenRechts);
            this.Controls.Add(this.btOvermakenLinks);
            this.Controls.Add(this.tbInvoerRechtsEuros);
            this.Controls.Add(this.lblInvoerRechts);
            this.Controls.Add(this.tbInvoerLinksEuros);
            this.Controls.Add(this.lblInvoerLinks);
            this.Controls.Add(this.gbAccountRechts);
            this.Controls.Add(this.gbAccountLinks);
            this.Name = "BankAccountForm";
            this.Text = "Bank Account";
            this.gbAccountLinks.ResumeLayout(false);
            this.gbAccountLinks.PerformLayout();
            this.gbAccountRechts.ResumeLayout(false);
            this.gbAccountRechts.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbAccountLinks;
        private System.Windows.Forms.Button btOvermakenLinks;
        private System.Windows.Forms.Button btOpnemenLinks;
        private System.Windows.Forms.Button btStortenLinks;
        private System.Windows.Forms.Label lblSaldoValueLinks;
        private System.Windows.Forms.Label lblSaldoLinks;
        private System.Windows.Forms.GroupBox gbAccountRechts;
        private System.Windows.Forms.Button btOvermakenRechts;
        private System.Windows.Forms.Button btOpnemenRechts;
        private System.Windows.Forms.Button btStortenRechts;
        private System.Windows.Forms.Label lblSaldoValueRechts;
        private System.Windows.Forms.Label lblSaldoRechts;
        private System.Windows.Forms.Label lblInvoerLinks;
        private System.Windows.Forms.TextBox tbInvoerLinksEuros;
        private System.Windows.Forms.TextBox tbInvoerRechtsEuros;
        private System.Windows.Forms.Label lblInvoerRechts;
        private System.Windows.Forms.TextBox tbInvoerLinksCenten;
        private System.Windows.Forms.TextBox tbInvoerRechtsCenten;
        private System.Windows.Forms.Label lblPuntLinks;
        private System.Windows.Forms.Label lblPuntRechts;
    }
}

