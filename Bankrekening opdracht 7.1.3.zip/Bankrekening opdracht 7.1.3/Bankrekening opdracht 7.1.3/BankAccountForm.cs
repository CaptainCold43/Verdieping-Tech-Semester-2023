﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bankrekening_opdracht_7._1._3
{
    public partial class BankAccountForm : Form
    {
        Account account1;
        Account account2;
        double Geld;
        double bedrag;
        string errormessage = "Het ingevulde bedrag moet positief zijn";
        bool positief = false;
        public BankAccountForm()
        {
            InitializeComponent();
            account1 = new Account("GSP", 9999999.99);
            account2 = new Account("RCE", 424.24);
            updateGUI();
        }

        private void btStortenLinks_Click(object sender, EventArgs e)
        {
            geldLinks();
            if (positief == true)
            {
                account1.Deposit(Geld);
            }
            updateGUI();
        }

        private void btStortenRechts_Click(object sender, EventArgs e)
        {
            geldRechts();
            if (positief == true)
            {
                account2.Deposit(Geld);
            }
            updateGUI();
        }

        private void btOpnemenLinks_Click(object sender, EventArgs e)
        {
            geldLinks();
            if (positief == true)
            {
                account1.Withdraw(Geld);
            }
            updateGUI();
        }

        private void btOpnemenRechts_Click(object sender, EventArgs e)
        {
            geldRechts();
            if (positief == true)
            {
                account2.Withdraw(Geld);
            }
            updateGUI();
        }

        private void btOvermakenLinks_Click(object sender, EventArgs e)
        {
            geldLinks();
            if (positief == true)
            {
                account1.Transfer(account2, Geld);
            }
            updateGUI();
        }

        private void btOvermakenRechts_Click(object sender, EventArgs e)
        {
            geldRechts();
            if (positief == true)
            {
                account2.Transfer(account1, Geld);
            }
            updateGUI();
        }
        // Deze functies zorgen ervoor dat het geld wordt geconvert to de juiste variable
        public void geldLinks()
        {
            bedrag = Convert.ToDouble(tbInvoerLinksEuros.Text) + Convert.ToDouble(tbInvoerLinksCenten.Text) / 100;
            positief = NietMinus();
            if (positief == true)
            {
                Geld = bedrag;
            }
            
        }
        public void geldRechts()
        {
            bedrag = Convert.ToDouble(tbInvoerRechtsEuros.Text) + Convert.ToDouble(tbInvoerRechtsCenten.Text) / 100;
            positief = NietMinus();
            if (positief == true)
            {
                Geld = bedrag;
            }
            
        }
        // Deze functie checkt of het ingevulde getal onder de nul is
        public bool NietMinus()
        {
            if (bedrag >= 0)
            {
                return true;
            }
            else 
            {
                MessageBox.Show(errormessage);
                return false;
            }
        }
        // Deze functies zorgen ervoor dat het Saldo wordt aangepast
        public void overmakenLinksNaarRechts()
        {
            account1.Transfer(account2, Geld);
        }
        public void overmakenRechtsNaarLinks()
        {
            account2.Transfer(account1, Geld);
        }
        // Deze functie Update de GUI
        public void updateGUI()
        {
            lblSaldoValueLinks.Text = Convert.ToString(account1.saldo);
            lblSaldoValueRechts.Text = Convert.ToString(account2.saldo);
            tbInvoerLinksEuros.Text = "0";
            tbInvoerLinksCenten.Text = "00";
            tbInvoerRechtsEuros.Text = "0";
            tbInvoerRechtsCenten.Text = "00";
        }
    }
}
