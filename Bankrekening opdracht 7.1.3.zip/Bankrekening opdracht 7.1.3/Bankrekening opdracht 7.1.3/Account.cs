﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bankrekening_opdracht_7._1._3
{
    public class Account
    {
        private string naam;
        private double Saldo;
        private int ID;
        private static int VolgendeID = 2001;
        private string errormessage = "Het Saldo moet positief blijven";
        // Constructors
        public Account(string naam) 
        {
            this.naam = naam;
            // Dit zorgt ervoor dat het volgende account dat wordt aangemaakt het volgende nummer heeft
            ID = VolgendeID;
            VolgendeID++;
        }
        public Account(string naam, double Bedrag)
        {
            this.naam = naam;
            Saldo = Bedrag;
            // Dit zorgt ervoor dat het volgende account dat wordt aangemaakt het volgende nummer heeft
            ID = VolgendeID;
            VolgendeID++;
        }
        // Methodes
        public double Deposit(double bedrag)
        {
            Saldo += bedrag;
            return Saldo;
        }
        public double Withdraw(double bedrag)
        {
            if (Saldo - bedrag >= 0)
            {
                Saldo -= bedrag;
            }
            else
            {
                MessageBox.Show(errormessage);
            }
            return Saldo;
        }
        public double Transfer(Account andereRekening, double bedrag)
        {
            if (Saldo - bedrag >= 0)
            {
                Saldo -= bedrag;
                andereRekening.Deposit(bedrag);
            }
            else
            {
                MessageBox.Show(errormessage);
            }
            return Saldo;
        }
        public double saldo
        {
            get { return Saldo; }
        }
    }
}
