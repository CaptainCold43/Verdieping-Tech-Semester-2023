﻿using MySql.Data.MySqlClient;

class DBConnection
{
    public int UserID { get; set; }
    public int Punten { get; set; }
    public int Kansen { get; set; }

    public void RetrieveDataFromDatabase(int user, string connectionString)
    {
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            connection.Open();

            string query = $"SELECT UserID, Punten, Kansen FROM slimmespenders WHERE UserID = {user}";
            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        UserID = reader.GetInt32(reader.GetOrdinal("UserID"));
                        Punten = reader.GetInt32(reader.GetOrdinal("Punten"));
                        Kansen = reader.GetInt32(reader.GetOrdinal("Kansen"));
                    }
                }
            }
            connection.Close();
        }
    }

    public void SendDataToDatabase(int user, string connectionString)
    {
        // Establish database connection
        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            connection.Open();
            // Execute SQL query to update data
            string query = $"UPDATE slimmespenders SET Punten = @Punten, Kansen = @Kansen WHERE UserID = {user}";
            using (MySqlCommand command = new MySqlCommand(query, connection))
            {
                command.Parameters.AddWithValue($"@Punten", Punten);
                command.Parameters.AddWithValue($"@Kansen", Kansen);
                command.ExecuteNonQuery();
            }
        }
    }
}
