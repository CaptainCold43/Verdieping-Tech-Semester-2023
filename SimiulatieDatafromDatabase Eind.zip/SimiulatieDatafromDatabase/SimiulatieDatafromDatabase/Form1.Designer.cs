﻿namespace SimiulatieDatafromDatabase
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tBUserIDInvullen = new System.Windows.Forms.TextBox();
            this.btGetData = new System.Windows.Forms.Button();
            this.btSendData = new System.Windows.Forms.Button();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblPunten = new System.Windows.Forms.Label();
            this.lblKansen = new System.Windows.Forms.Label();
            this.cBportlist = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.btOpenSerial = new System.Windows.Forms.Button();
            this.btCloseSerial = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblBarcodeArduino = new System.Windows.Forms.Label();
            this.lblPuntenArduino = new System.Windows.Forms.Label();
            this.lblKansenArduino = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rTBArduinoresponse = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // tBUserIDInvullen
            // 
            this.tBUserIDInvullen.Location = new System.Drawing.Point(12, 120);
            this.tBUserIDInvullen.Name = "tBUserIDInvullen";
            this.tBUserIDInvullen.Size = new System.Drawing.Size(100, 22);
            this.tBUserIDInvullen.TabIndex = 0;
            // 
            // btGetData
            // 
            this.btGetData.Location = new System.Drawing.Point(12, 148);
            this.btGetData.Name = "btGetData";
            this.btGetData.Size = new System.Drawing.Size(75, 23);
            this.btGetData.TabIndex = 1;
            this.btGetData.Text = "Get Data";
            this.btGetData.UseVisualStyleBackColor = true;
            this.btGetData.Click += new System.EventHandler(this.btGetData_Click);
            // 
            // btSendData
            // 
            this.btSendData.Location = new System.Drawing.Point(93, 148);
            this.btSendData.Name = "btSendData";
            this.btSendData.Size = new System.Drawing.Size(82, 23);
            this.btSendData.TabIndex = 2;
            this.btSendData.Text = "Send Data";
            this.btSendData.UseVisualStyleBackColor = true;
            this.btSendData.Click += new System.EventHandler(this.btSendData_Click);
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Location = new System.Drawing.Point(317, 42);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(55, 16);
            this.lblUserID.TabIndex = 3;
            this.lblUserID.Text = "UserID: ";
            // 
            // lblPunten
            // 
            this.lblPunten.AutoSize = true;
            this.lblPunten.Location = new System.Drawing.Point(317, 58);
            this.lblPunten.Name = "lblPunten";
            this.lblPunten.Size = new System.Drawing.Size(54, 16);
            this.lblPunten.TabIndex = 4;
            this.lblPunten.Text = "Punten: ";
            // 
            // lblKansen
            // 
            this.lblKansen.AutoSize = true;
            this.lblKansen.Location = new System.Drawing.Point(317, 74);
            this.lblKansen.Name = "lblKansen";
            this.lblKansen.Size = new System.Drawing.Size(58, 16);
            this.lblKansen.TabIndex = 5;
            this.lblKansen.Text = "Kansen: ";
            // 
            // cBportlist
            // 
            this.cBportlist.FormattingEnabled = true;
            this.cBportlist.Location = new System.Drawing.Point(88, 10);
            this.cBportlist.Name = "cBportlist";
            this.cBportlist.Size = new System.Drawing.Size(121, 24);
            this.cBportlist.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "SerialPort:";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // btOpenSerial
            // 
            this.btOpenSerial.Location = new System.Drawing.Point(12, 37);
            this.btOpenSerial.Name = "btOpenSerial";
            this.btOpenSerial.Size = new System.Drawing.Size(75, 64);
            this.btOpenSerial.TabIndex = 8;
            this.btOpenSerial.Text = "Open";
            this.btOpenSerial.UseVisualStyleBackColor = true;
            this.btOpenSerial.Click += new System.EventHandler(this.btOpenSerial_Click);
            // 
            // btCloseSerial
            // 
            this.btCloseSerial.Location = new System.Drawing.Point(94, 37);
            this.btCloseSerial.Name = "btCloseSerial";
            this.btCloseSerial.Size = new System.Drawing.Size(75, 64);
            this.btCloseSerial.TabIndex = 9;
            this.btCloseSerial.Text = "Close";
            this.btCloseSerial.UseVisualStyleBackColor = true;
            this.btCloseSerial.Click += new System.EventHandler(this.btCloseSerial_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(320, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Binnen van Database";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(506, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Binnen van Arduino";
            // 
            // lblBarcodeArduino
            // 
            this.lblBarcodeArduino.AutoSize = true;
            this.lblBarcodeArduino.Location = new System.Drawing.Point(509, 41);
            this.lblBarcodeArduino.Name = "lblBarcodeArduino";
            this.lblBarcodeArduino.Size = new System.Drawing.Size(62, 16);
            this.lblBarcodeArduino.TabIndex = 12;
            this.lblBarcodeArduino.Text = "Barcode:";
            this.lblBarcodeArduino.TextChanged += new System.EventHandler(this.lblBarcodeArduino_TextChanged);
            // 
            // lblPuntenArduino
            // 
            this.lblPuntenArduino.AutoSize = true;
            this.lblPuntenArduino.Location = new System.Drawing.Point(317, 199);
            this.lblPuntenArduino.Name = "lblPuntenArduino";
            this.lblPuntenArduino.Size = new System.Drawing.Size(51, 16);
            this.lblPuntenArduino.TabIndex = 13;
            this.lblPuntenArduino.Text = "Punten:";
            // 
            // lblKansenArduino
            // 
            this.lblKansenArduino.AutoSize = true;
            this.lblKansenArduino.Location = new System.Drawing.Point(317, 215);
            this.lblKansenArduino.Name = "lblKansenArduino";
            this.lblKansenArduino.Size = new System.Drawing.Size(55, 16);
            this.lblKansenArduino.TabIndex = 14;
            this.lblKansenArduino.Text = "Kansen:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(320, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(231, 16);
            this.label7.TabIndex = 15;
            this.label7.Text = "Versturen van Arduino naar Database";
            // 
            // rTBArduinoresponse
            // 
            this.rTBArduinoresponse.Location = new System.Drawing.Point(16, 177);
            this.rTBArduinoresponse.Name = "rTBArduinoresponse";
            this.rTBArduinoresponse.Size = new System.Drawing.Size(292, 227);
            this.rTBArduinoresponse.TabIndex = 16;
            this.rTBArduinoresponse.Text = "";
            this.rTBArduinoresponse.TextChanged += new System.EventHandler(this.rTBArduinoresponse_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rTBArduinoresponse);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblKansenArduino);
            this.Controls.Add(this.lblPuntenArduino);
            this.Controls.Add(this.lblBarcodeArduino);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btCloseSerial);
            this.Controls.Add(this.btOpenSerial);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cBportlist);
            this.Controls.Add(this.lblKansen);
            this.Controls.Add(this.lblPunten);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.btSendData);
            this.Controls.Add(this.btGetData);
            this.Controls.Add(this.tBUserIDInvullen);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tBUserIDInvullen;
        private System.Windows.Forms.Button btGetData;
        private System.Windows.Forms.Button btSendData;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblPunten;
        private System.Windows.Forms.Label lblKansen;
        private System.Windows.Forms.ComboBox cBportlist;
        private System.Windows.Forms.Label label1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button btOpenSerial;
        private System.Windows.Forms.Button btCloseSerial;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblBarcodeArduino;
        private System.Windows.Forms.Label lblPuntenArduino;
        private System.Windows.Forms.Label lblKansenArduino;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rTBArduinoresponse;
    }
}

