﻿using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace SimiulatieDatafromDatabase
{
    public partial class Form1 : Form
    {
        int puntenFromArduino; // data String
        int kansenFromArduino;

        int ind1; // , locations
        int ind2;
        int ind3;

        bool barcodesent = false;
        string data_arduino;
        string serialDataIn;
        readonly string connectionstring = "Server=studmysql01.fhict.local; Database=dbi454078; Uid=dbi454078; Pwd=djoerdie69;";
        int barcode;
        DBConnection connection = new DBConnection();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btOpenSerial.Enabled = true;
            btCloseSerial.Enabled = false;
            string[] portlists = SerialPort.GetPortNames();
            cBportlist.Items.AddRange(portlists);
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void btOpenSerial_Click(object sender, EventArgs e)
        {
            openSerialPort();
        }

        private void btCloseSerial_Click(object sender, EventArgs e)
        {
            closeSerialPort();
        }

        private void btGetData_Click(object sender, EventArgs e)
        {
            try
            {
                connection.RetrieveDataFromDatabase(Convert.ToInt32(tBUserIDInvullen.Text), connectionstring);
                barcode = Convert.ToInt32(tBUserIDInvullen.Text);
                serialPort1.Write("Goedgekeurd#");
                // connection.RetrieveDataFromDatabase(connection.UserID, connectionstring);
                lblUserID.Text = "UserID: " + connection.UserID;
                lblPunten.Text = "Punten: " + Convert.ToString(connection.Punten);
                lblKansen.Text = "Kansen: " + Convert.ToString(connection.Kansen);
                puntenFromArduino = connection.Punten;
                kansenFromArduino = connection.Kansen;
                serialPort1.Write(connection.Punten.ToString() + ", " + connection.Kansen.ToString() + "#");
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btSendData_Click(object sender, EventArgs e)
        {
            connection.Punten = puntenFromArduino;
            connection.Kansen = kansenFromArduino;
            // connection.SendDataToDatabase(Convert.ToInt32(tBUserIDInvullen.Text), connectionstring);
            connection.SendDataToDatabase(connection.UserID, connectionstring);
            //lblPuntenArduino.Text = "Punten: " + Convert.ToString(puntenFromArduino);
            //lblKansenArduino.Text = "Kansen: " + Convert.ToString(kansenFromArduino);
            lblUserID.Text = "UserID: ";
            lblPunten.Text = "Punten: ";
            lblKansen.Text = "Kansen: ";
        }
        private void openSerialPort()
        {
            try
            {
                btOpenSerial.Enabled = false;
                btCloseSerial.Enabled = true;
                serialPort1.PortName = cBportlist.Text;
                serialPort1.Open();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        private void closeSerialPort()
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    btOpenSerial.Enabled = true;
                    btCloseSerial.Enabled = false;
                    serialPort1.Close();
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            serialDataIn = serialPort1.ReadExisting();
            this.Invoke(new EventHandler(ShowData));
        }
        private void ShowData(object sender, EventArgs e)
        {
            rTBArduinoresponse.Text += serialDataIn;
            if (!serialDataIn.Contains("#"))
            {
                data_arduino += serialDataIn;
            }
            else if (serialDataIn.Contains("#"))
            {
                try
                {
                    decoderenBericht(data_arduino);
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
                data_arduino = "";
            }
        }
        private void rTBArduinoresponse_TextChanged(object sender, EventArgs e)
        {
            rTBArduinoresponse.SelectionStart = rTBArduinoresponse.Text.Length;
            rTBArduinoresponse.ScrollToCaret();
        }

        private void lblBarcodeArduino_TextChanged(object sender, EventArgs e)
        {

            //if (barcode == connection.UserID)
            //{
            //    serialPort1.Write("Goedgekeurd#");
            //}
            //else
            //{
            //    serialPort1.Write("Afgekeurd#");
            //}

        }
        private void decoderenBericht(string message)
        {
            ind1 = message.IndexOf(',');                  // finds location of first ,
            // barcode = Convert.ToInt32(message.Substring(0, ind1));           // captures first data String
            ind2 = message.IndexOf(',', ind1 + 1);                  // finds location of first ,
            puntenFromArduino = Convert.ToInt32(message.Substring(ind1 + 1, ind2 + 1));
            ind3 = message.IndexOf(',', ind2 + 1);        // finds location of second ,
            kansenFromArduino = Convert.ToInt32(message.Substring(ind2 + 1)); //captures remain part of data after last
            if (barcode.ToString().Count() == 9)
            {
                //if (!barcodesent)
                //{
                //lblBarcodeArduino.Text = barcode.ToString();
                //barcodesent = true;
                //}
                //else if (barcodesent)
                //{
                lblPuntenArduino.Text = "Punten: " + puntenFromArduino.ToString();
                lblKansenArduino.Text = "Kansen: " + kansenFromArduino.ToString();
                barcodesent = false;
                //}
            }
        }
    }
}