#include <Arduino.h>
int puntenstart = 0;
int kansenstart = 0;
int kansen = 0;
int punten = 0;
bool boolpunten = true;
bool boolkansen = true;
bool barcodegescand = false;
char c;
String appendSerialData;

void wachttimer()
{
    unsigned long oldmillis = millis();
    while (millis() - oldmillis < 5000)
    {
    }
    Serial.println("page 2");
}

void gegevensophalen()
{
    puntenstart = 1000;
    kansenstart = 23;
    punten = puntenstart;
    kansen = kansenstart;
}
void gegevenssturen()
{
}
void newbarcode()
{
}
void readbarcode()
{
    gegevensophalen();
    barcodegescand = true;
}

void display()
{
    if (appendSerialData == "Bevestigen#")
    {
        Serial.println("page 1");
        gegevenssturen();
    }
    else if (appendSerialData == "puntenmin#")
    {
        if (punten - 100 >= 0)
        {
            Serial.print("punten.val=");
            punten -= 100;
            Serial.println(punten);
        }
        else
        {
            Serial.println("page 5");
            wachttimer();
        }
    }
    else if (appendSerialData == "kansenplus#")
    {
        Serial.print("kansen.val=");
        kansen += 1;
        Serial.println(kansen);
    }
    else if (appendSerialData == "puntenplus#")
    {
        if (punten != puntenstart)
        {
            Serial.print("punten.val=");
            punten += 100;
            Serial.println(punten);
        }
        else
        {
            Serial.println("page 3");
            wachttimer();
        }
    }
    else if (appendSerialData == "kansenmin#")
    {
        if (kansen != kansenstart)
        {
            Serial.print("punten.val=");
            kansen -= 1;
            Serial.println(kansen);
        }
        else
        {
            Serial.println("page 4");
            wachttimer();
        }
    }
    else
    {
        Serial.println("page 1");
        wachttimer();
    }
    appendSerialData = "";
    c = '%'; //???
}

void lezen()
{
    while (Serial.available() > 0)
    {
        c = Serial.read();
        appendSerialData += c;
    }
    if (c == '#')
    {
        // debuggen
        Serial.print("Data recieved ");
        Serial.println(appendSerialData);
        display();
    }
}

void setup()
{
    // put your setup code here, to run once:
    Serial.begin(9600);
    Serial.println("page 0");
    // debuggen
    Serial.println("test");
}

void loop()
{
    // put your main code here, to run repeatedly:
    if (barcodegescand == true)
    {
        lezen();
    }
    else
    {
        readbarcode();
    }
}