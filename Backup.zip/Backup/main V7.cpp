#include <Arduino.h>
#include <SoftwareSerial.h>
SoftwareSerial Serial2(2, 3); // RX, TX
int puntenstart = 0;
int kansenstart = 0;
int kansen = 0;
int punten = 0;
bool boolpunten = true;
bool boolkansen = true;
bool barcodegescand = false;
bool Goedkeuring = false;
char c;
char x;
long barcode = 000000000;
String data_from_display;
String data_from_Csharp;
// union
// {
//     unsigned long getDataLong;
//     byte getDataByteArray[4];
// } getDataUnion;
int Value; // data String
String Type;

int ind1; // , locations
int ind2;

void wachttimer()
{
    unsigned long oldmillis = millis();
    while (millis() - oldmillis < 5000)
    {
    }
    // Serial.print("page 2");
    Serial2.print("page 2");
    Serial2.write(0xff);
    Serial2.write(0xff);
    Serial2.write(0xff);
}
void gegevensophalen()
{
    puntenstart = 1000;
    kansenstart = 23;
    punten = puntenstart;
    kansen = kansenstart;
    barcode = 123456789;
    Serial.println("Barcode:" + String(barcode) + "#");
}
void gegevenssturen()
{
    barcodegescand = false;
    Serial.println("Punten:" + String(punten) + "#");
    Serial.println("Kansen:" + String(kansen) + "#");
}
void newbarcode()
{
}
void readbarcode()
{
    gegevensophalen();
    // Serial.println("barcodeval=" + String(barcode));
    Serial2.print("barcode.val=" + String(barcode));
    Serial2.write(0xff);
    Serial2.write(0xff);
    Serial2.write(0xff);
    barcodegescand = true;
}
void    getValueFromCsharp(String message)
{
    ind1 = message.indexOf(',');                  // finds location of first ,
    puntenstart = message.substring(0, ind1).toInt();           // captures first data String
    ind2 = message.indexOf(',', ind1 + 1);        // finds location of second ,
    kansenstart = message.substring(ind1+1).toInt(); //captures remain part of data after last
    Serial.println(ind1);
    Serial.println(Value);
    Serial.println(ind2);
    Serial.println(Type);
}
void C_Applicatie()
{
    if (Goedkeuring)
    {
        getValueFromCsharp(data_from_Csharp);
    }
    else if (data_from_Csharp == "Goedgekeurd#")
    {
        Goedkeuring = true;
        Serial2.print("page 2");
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
        wachttimer();
    }
    else if (data_from_Csharp == "Afgekeurd#")
    {
        Goedkeuring = false;
        Serial2.print("page 6");
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
        wachttimer();
    }
    data_from_Csharp = "";
    x = '%';
}

void display()
{
    if (data_from_display == "Bevestigen#")
    {
        // Serial.println("page 1");
        Serial2.print("page 1");
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
        gegevenssturen();
    }
    else if (data_from_display == "puntenmin#")
    {
        if (punten - 100 >= 0)
        {
            punten -= 100;
            // Serial.println("Gescand.punten.val=" + String(punten));
            Serial2.print("Gescand.punten.val=" + String(punten));
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
        }
        else
        {
            // Serial.println("page 5");
            Serial2.print("page 5");
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
            wachttimer();
        }
    }
    else if (data_from_display == "kansenplus#")
    {
        kansen += 1;
        // Serial.println("Gescand.kansen.val=" + String(kansen));
        Serial2.print("Gescand.kansen.val=" + String(kansen));
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
    }
    else if (data_from_display == "puntenplus#")
    {
        if (punten != puntenstart)
        {
            punten += 100;
            // Serial.println("Gescand.punten.val=" + String(punten));
            Serial2.print("Gescand.punten.val=" + String(punten));
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
        }
        else
        {
            // Serial.println("page 3");
            Serial2.print("page 3");
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
            wachttimer();
        }
    }
    else if (data_from_display == "kansenmin#")
    {
        if (kansen != kansenstart)
        {
            kansen -= 1;
            // Serial.println("Gescand.kansen.val=" + String(kansen));
            Serial2.print("Gescand.kansen.val=" + String(kansen));
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
        }
        else
        {
            // Serial.println("page 4");
            Serial2.print("page 4");
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
            wachttimer();
        }
    }
    else
    {
        // Serial.println("page 1");
        Serial2.print("page 1");
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
        wachttimer();
    }
    // getDataUnion.getDataLong=0;
    data_from_display = "";
    c = '%'; //???
}

void lezen()
{
    while (Serial2.available() > 0)
    {
        c = Serial2.read();
        data_from_display += c;
    }
    // if (data_from_display.substring(0, 1) == "q")
    // {
    //     for (int x = 0; x < 4; x++)
    //     {
    //         Serial.println(String(data_from_display[x], HEX));
    //         getDataUnion.getDataByteArray[x] = data_from_display[x + 1];
    //         Serial.println("Value is = " + String(getDataUnion.getDataLong));
    //     }
    // }
    while (Serial.available() > 0)
    {
        x = Serial.read();
        data_from_Csharp += x;
    }
    if (c == '#')
    {
        // debuggen
        // Serial.print("Data recieved ");
        // Serial.println(data_from_display);
        display();
    }
    if (x == '#')
    {
        C_Applicatie();
    }
}

void setup()
{
    // put your setup code here, to run once:
    Serial.begin(9600); // checken voor bitrate
    Serial2.begin(9600);
    // Serial.println("page 0");
    Serial2.print("page 0");
    Serial2.write(0xff);
    Serial2.write(0xff);
    Serial2.write(0xff);
    // debuggen
    // Serial.println("test");
}

void loop()
{
    // put your main code here, to run repeatedly:
    if (barcodegescand == true)
    {
        lezen();
    }
    else
    {
        readbarcode();
    }
}