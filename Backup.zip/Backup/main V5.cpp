#include <Arduino.h>
int puntenstart = 0;
int kansenstart = 0;
int kansen = 0;
int punten = 0;
bool boolpunten = true;
bool boolkansen = true;
bool barcodegescand = false;
char c;
String appendSerialData;

void wachttimer()
{
    unsigned long oldmillis = millis();
    while (millis() - oldmillis < 5000)
    {
    }
    Serial.write("page 2");
}

void gegevensophalen()
{
    puntenstart = 1000;
    kansenstart = 23;
    punten = puntenstart;
    kansen = kansenstart;
}
void gegevenssturen()
{
}
void newbarcode()
{
}
void readbarcode()
{
    gegevensophalen();
    barcodegescand = true;
}

void display()
{
    if (appendSerialData == "Bevestigen#")
    {
        Serial.write("page 1");
        gegevenssturen();
    }
    else if (appendSerialData == "puntenmin#")
    {
        if (punten - 100 >= 0)
        {
          punten -= 100;
            Serial.write("punten.val=" + punten);
        }
        else
        {
            Serial.write("page 5");
            wachttimer();
        }
    }
    else if (appendSerialData == "kansenplus#")
    {
        kansen += 1;
        Serial.write("kansen.val=" + kansen);
    }
    else if (appendSerialData == "puntenplus#")
    {
        if (punten != puntenstart)
        {
            punten += 100;
            Serial.write("punten.val=" + punten);
        }
        else
        {
            Serial.write("page 3");
            wachttimer();
        }
    }
    else if (appendSerialData == "kansenmin#")
    {
        if (kansen != kansenstart)
        {
            kansen -= 1;
            Serial.write("punten.val=" + kansen);
  
        }
        else
        {
            Serial.write("page 4");
            wachttimer();
        }
    }
    else
    {
        Serial.write("page 1");
        wachttimer();
    }
    appendSerialData = "";
    c = '%'; //???
}

void lezen()
{
    while (Serial.available() > 0)
    {
        c = Serial.read();
        appendSerialData += c;
    }
    if (c == '#')
    {
        // debuggen
        Serial.write("Data recieved ");
        Serial.println(appendSerialData);
        display();
    }
}

void setup()
{
    // put your setup code here, to run once:
    Serial.begin(9600);
    Serial.write("page 0");
    // debuggen
    Serial.println("test");
}

void loop()
{
    // put your main code here, to run repeatedly:
    if (barcodegescand == true)
    {
        lezen();
    }
    else
    {
        readbarcode();
    }
}