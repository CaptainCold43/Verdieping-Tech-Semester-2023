#include <Arduino.h>
#include <SoftwareSerial.h>
SoftwareSerial Serial2(2, 3); // RX, TX
int puntenstart = 0;
int kansenstart = 0;
int kansen = 0;
int punten = 0;
bool boolpunten = true;
bool boolkansen = true;
bool barcodegescand = false;
char c;
String appendSerialData;

void wachttimer()
{
    unsigned long oldmillis = millis();
    while (millis() - oldmillis < 5000)
    {
    }
    Serial2.print("page 2");
    Serial2.write(0xff);
    Serial2.write(0xff);
    Serial2.write(0xff);
}

void gegevensophalen()
{
    puntenstart = 1000;
    kansenstart = 23;
    punten = puntenstart;
    kansen = kansenstart;
}
void gegevenssturen()
{
}
void newbarcode()
{
}
void readbarcode()
{
    gegevensophalen();
    barcodegescand = true;
}

void display()
{
    if (appendSerialData == "Bevestigen#")
    {
        Serial2.print("page 1");
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
        gegevenssturen();
    }
    else if (appendSerialData == "puntenmin#")
    {
        if (punten - 100 >= 0)
        {
            punten -= 100;
            Serial2.print("punten.val=" + String(punten));
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
        }
        else
        {
            Serial2.print("page 5");
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
            wachttimer();
        }
    }
    else if (appendSerialData == "kansenplus#")
    {
        kansen += 1;
        Serial2.print("kansen.val=" + String(kansen));
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
    }
    else if (appendSerialData == "puntenplus#")
    {
        if (punten != puntenstart)
        {
            punten += 100;
            Serial2.print("punten.val=" + String(punten));
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
        }
        else
        {
            Serial2.print("page 3");
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
            wachttimer();
        }
    }
    else if (appendSerialData == "kansenmin#")
    {
        if (kansen != kansenstart)
        {
            kansen -= 1;
            Serial2.print("punten.val=" + String(kansen));
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
        }
        else
        {
            Serial2.print("page 4");
            Serial2.write(0xff);
            Serial2.write(0xff);
            Serial2.write(0xff);
            wachttimer();
        }
    }
    else
    {
        Serial2.print("page 1");
        Serial2.write(0xff);
        Serial2.write(0xff);
        Serial2.write(0xff);
        wachttimer();
    }
    appendSerialData = "";
    c = '%'; //???
}

void lezen()
{
    while (Serial2.available() > 0)
    {
        c = Serial2.read();
        appendSerialData += c;
    }
    if (c == '#')
    {
        // debuggen
        Serial.print("Data recieved ");
        Serial.println(appendSerialData);
        display();
    }
}

void setup()
{
    // put your setup code here, to run once:
    Serial2.begin(9600); // checken voor bitrate
    Serial2.begin(9600);
    Serial2.print("page 0");
    Serial2.write(0xff);
    Serial2.write(0xff);
    Serial2.write(0xff);
    // debuggen
    Serial.println("test");
}

void loop()
{
    // put your main code here, to run repeatedly:
    if (barcodegescand == true)
    {
        lezen();
    }
    else
    {
        readbarcode();
    }
}